import logging

import requests

from odoo import models

_logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = 10


class ProductAILookup(models.Model):
    """Thin bridge between the Odoo AI agent and the external Flask
    Product Master API. Regular Server Actions run inside a restricted
    Python sandbox that cannot import 'requests' directly, so this real
    model method does the HTTP call instead. The Server Action / AI Tool
    just calls env['product.ai.lookup'].search_product(query).
    """

    _name = "product.ai.lookup"
    _description = "Product Master API Lookup for AI Agent"

    def _get_api_base_url(self):
        # Configurable from Settings > Technical > System Parameters
        # so you never have to touch code after deploying to Render.
        return (
            self.env["ir.config_parameter"]
            .sudo()
            .get_param("product_ai_lookup.api_base_url", default="")
            .rstrip("/")
        )

    def search_product(self, query):
        """Calls GET /api/agent/lookup?q=<query> on the Flask API and
        returns a dict ready for the AI agent to use in its reply.
        """
        base_url = self._get_api_base_url()
        if not base_url:
            return {
                "found": False,
                "message": (
                    "Product API base URL is not configured. Set the "
                    "'product_ai_lookup.api_base_url' system parameter "
                    "to your Render URL, e.g. https://your-app.onrender.com"
                ),
            }

        try:
            response = requests.get(
                f"{base_url}/api/agent/lookup",
                params={"q": query},
                timeout=DEFAULT_TIMEOUT,
            )
            response.raise_for_status()
            data = response.json()
        except Exception as exc:  # noqa: BLE001 - want to surface any failure to the agent
            _logger.exception("Product AI Lookup: API call failed for query=%r", query)
            return {"found": False, "message": f"Could not reach the product catalog: {exc}"}

        if not data.get("found"):
            return {"found": False, "message": data.get("message", "Product not found.")}

        product = data.get("product", {})
        image_url = product.get("image_url")
        image_urls = product.get("image_urls") or ([image_url] if image_url else [])
        reply_text = data.get("reply_text", "")

        # HTML version so the image renders inline in Discuss / Live Chat replies.
        html_reply = f"<p>{reply_text.replace(chr(10), '<br/>')}</p>"
        for url in image_urls:
            html_reply += f'<img src="{url}" style="max-width:300px;" alt="{product.get("name", "")}"/>'

        return {
            "found": True,
            "reply_text": reply_text,
            "html_reply": html_reply,
            "image_url": image_url,
            "image_urls": image_urls,
            "product": product,
        }
