{
    "name": "Product AI Lookup",
    "version": "19.0.1.0.0",
    "summary": "Connects the Odoo AI agent to your external Product Master API (Flask, hosted on Render)",
    "category": "Productivity",
    "author": "Custom",
    "depends": ["base"],
    "data": [
        "data/ir_config_parameter.xml",
    ],
    "installable": True,
    "application": False,
    "license": "LGPL-3",
}
